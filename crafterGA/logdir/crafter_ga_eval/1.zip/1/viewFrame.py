import numpy as np
import argparse
import matplotlib.pyplot as plt
import matplotlib.animation as animation

numDict = {}
numDict[0] = np.load('nums/0.npy')
numDict[1] = np.load('nums/1.npy')
numDict[2] = np.load('nums/2.npy')
numDict[3] = np.load('nums/3.npy')
numDict[4] = np.load('nums/4.npy')
numDict[5] = np.load('nums/5.npy')
numDict[6] = np.load('nums/6.npy')
numDict[7] = np.load('nums/7.npy')
numDict[8] = np.load('nums/8.npy')
numDict[9] = np.load('nums/9.npy')

def createAnim(obsVec):
    """Creates and saves an MP4 animation from a vector of observations."""
    fig, ax = plt.subplots()
    ax.axis('off')

    im = ax.imshow(obsVec[0])

    def update(frame):
        """Update function for the animation."""
        im.set_data(obsVec[frame])
        return [im]

    ani = animation.FuncAnimation(fig=fig, func=update, frames=len(obsVec), interval=100, blit=True)
    ani.save('crafter_animation.mp4', writer='ffmpeg')
    print("Animation saved successfully as crafter_animation.mp4!")

def showObs(obs):
  """Displays a single observation frame with a grid overlay."""
  observation = np.array(obs)
  height, width, _ = observation.shape
  grid_size = 7 # Define the size of each grid cell

  fig, ax = plt.subplots(1, figsize=(5, 5))
  ax.imshow(observation)

  # Set positions for grid lines
  x_ticks = np.arange(0, width, grid_size)
  y_ticks = np.arange(0, height, grid_size)

  # Manually draw the grid lines
  for x in x_ticks:
      ax.axvline(x - 0.5, color='white', linestyle='--', linewidth=0.5, alpha=0.7)
  for y in y_ticks:
      ax.axhline(y - 0.5, color='white', linestyle='--', linewidth=0.5, alpha=0.7)

  ax.set_title("Observation Frame")
  ax.axis('off')
  
  # --- FIX: Save the image to a file ---
  # This will always work, even if plt.show() fails.

  # plt.show() will still try to open a window, which may fail
  # in some environments.
  plt.show()

def eraseBlock(obs,i,j):
    for x in range(i,i+7):
        for y in range(j,j+7):
            obs[x][y][0] = 100
            obs[x][y][1] = 100
            obs[x][y][2] = 100
    return obs

def extractResourceBar(obs):
    alteredObs = obs.copy()
    height, width, _ = alteredObs.shape
    blockSize = 7
    health = alteredObs[7*blockSize:7*blockSize+7,0*blockSize:0*blockSize+7].copy()
    food = alteredObs[7*blockSize:7*blockSize+7,1*blockSize:1*blockSize+7].copy()
    water= alteredObs[7*blockSize:7*blockSize+7,2*blockSize:2*blockSize+7].copy()
    stamina = alteredObs[7*blockSize:7*blockSize+7,3*blockSize:3*blockSize+7].copy()
    return health,food,water,stamina

def extractNum(resource):
    alteredResource = resource.copy()
    height, width, _ = resource.shape
    for i in range(height):
        for j in range(width):
            if np.array_equal(resource[i, j], [255, 255, 255]) and i >= 2 and j >= 2:
                alteredResource[i, j] = [255, 255, 255]
            else:
                alteredResource[i, j] = [0, 0, 0]
    return alteredResource

def extractResourceNum(resource):
    for i in range(10):
        if np.array_equal(resource, numDict[i]):
            return i
    return 0 # Default to 0 if not found

# --- Main Execution ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="View Crafter episode recordings.")
    parser.add_argument('--filename', default='episode.npz', help='The .npz file containing the episode data.')
    
    # Re-added the flag to choose between animation and first frame
    parser.add_argument(
        '--show_first_frame', 
        action='store_true', 
        help='Display and save only the first frame instead of creating an animation.'
    )
    
    args = parser.parse_args()

    try:
        f = np.load(args.filename)
        imageData = f['image']
    except FileNotFoundError:
        print(f"Error: The file '{args.filename}' was not found.")
        exit()
    except KeyError:
        print(f"Error: The file '{args.filename}' does not contain the 'image' key.")
        exit()

    # Conditionally call the appropriate function based on the flag
    if args.show_first_frame:
        print("Displaying and saving the first frame...")
        health,food,water,stamina = extractResourceBar(imageData[100])
        print(extractResourceNum(extractNum(food)))
        #np.save('nums/0.npy',extractNum(water))
        showObs(extractNum(food)) # Pass only the first frame
    else:
        print("Creating animation from episode frames...")
        createAnim(imageData)
